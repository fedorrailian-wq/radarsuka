package com.mycompany.radar;

import android.app.Activity;
import android.os.Bundle;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.ToggleButton;
import android.view.View;

public class MainActivity extends Activity {

    // Структура для 3D-координат игрового мира (X, Y, Z)
    class Vector3 {
        float x, y, z;
        Vector3(float x, float y, float z) {
            this.x = x; this.y = y; this.z = z;
        }
    }

    // Структура для 2D-координат на экране радара (X, Y)
    class Vector2D {
        float x, y;
        Vector2D(float x, float y) {
            this.x = x; this.y = y;
        }
    }

    // Твоя главная функция, которая пересчитывает метры игры в пиксели экрана
    Vector2D CalculateRadarPosition(Vector3 localPlayer, Vector3 enemy, float radarCenterX, float radarCenterY, float scale) {
        float deltaX = enemy.x - localPlayer.x;
        float deltaZ = enemy.z - localPlayer.z;
        
        float radarX = radarCenterX + (deltaX * scale);
        float radarY = radarCenterY + (deltaZ * scale);
        
        return new Vector2D(radarX, radarY);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Создаем вертикальный контейнер для интерфейса меню
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(40, 40, 40, 40);

        // Текст состояния радара
        final TextView textStatus = new TextView(this);
        textStatus.setText("Радар отключен. Нажмите кнопку для теста.");
        textStatus.setTextSize(20);

        // Кнопка включения радара
        final ToggleButton radarBtn = new ToggleButton(this);
        radarBtn.setTextOff("Включить Радар-Хак");
        radarBtn.setTextOn("Выключить Радар-Хак");
        radarBtn.setChecked(false);

        // Логика работы кнопки
        radarBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (radarBtn.isChecked()) {
                    // Твои тестовые координаты
                    Vector3 myPosition = new Vector3(0.0f, 0.0f, 0.0f);
                    Vector3 botPosition = new Vector3(15.0f, 0.0f, -25.0f);

                    float centerX = 100.0f; 
                    float centerY = 100.0f; 
                    float mapScale = 2.0f;  

                    // Запускаем твой расчет
                    Vector2D botOnRadar = CalculateRadarPosition(myPosition, botPosition, centerX, centerY, mapScale);

                    // Выводим результат прямо на экран телефона в меню
                    textStatus.setText("=== Радар-Хак Активен ===\n" +
                            "Точка отрисовки на радаре:\nX = " + botOnRadar.x + "\nY = " + botOnRadar.y);
                } else {
                    textStatus.setText("Радар отключен.");
                }
            }
        });

        // Добавляем элементы в наше меню
        layout.addView(textStatus);
        layout.addView(radarBtn);
        setContentView(layout);
    }
}